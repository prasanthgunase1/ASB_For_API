// const { logger } = require("../utils/logger");
// const { keycloak } = require("../config/keycloak");
// const statusCodes = require("../utils/statusCodes");
// const upload = require("./uploadMiddleware");
// const { MulterError } = require("multer"); // Import MulterError

// function extractUserFromToken(req, res, next) {
//   try {
//     if (req.kauth && req.kauth.grant && req.kauth.grant.access_token) {
//       const accessToken = req.kauth.grant.access_token.content;
//       req.user = {
//         username: accessToken.preferred_username,
//         name: accessToken.name,
//         userId: accessToken.sub,
//         email: accessToken.email,
//         image_url: accessToken.picture,
//         // ... other user information
//       };
//     }
//     next();
//   } catch (error) {
//     // Instead of logging locally, pass the error to the centralized error handler
//     next(error);
//   }
// }

// function authMiddleware(req, res, next) {
//   keycloak.protect(`${process.env.KEYCLOAK_CLIENT_ID}-USER`)(req, res, (authErr) => {
//     if (authErr) return next(authErr);

//     // Only apply upload middleware to specific routes
//     if (req.params.model === "message" || req.path === "/callback") {
//       upload.array("files", 1000)(req, res, (uploadErr) => {
//         if (uploadErr) {
//           // Handle Multer-specific errors
//           if (uploadErr instanceof MulterError) {
//             uploadErr.statusCode = statusCodes.BAD_REQUEST;
//             switch (uploadErr.code) {
//               case "LIMIT_FILE_TYPE":
//                 uploadErr.message = `Invalid file type.`;
//                 break;
//               case "LIMIT_FILE_SIZE":
//                 uploadErr.message = "Max file size is 20MB";
//                 break;
//               case "LIMIT_UNEXPECTED_FILE":
//                 uploadErr.message = "Max 5 files allowed";
//                 break;
//             }
//           }
//           // Ensure error has a statusCode
//           uploadErr.statusCode = uploadErr.statusCode || statusCodes.INTERNAL_SERVER_ERROR;
//           // Pass the error to the centralized error handler
//           return next(uploadErr);
//         }
//         // No upload error - continue processing
//         next();
//       });
//     } else {
//       // Not an upload route - continue normally
//       next();
//     }
//   });
// }

// module.exports = { extractUserFromToken, authMiddleware };

// UPDATED FOR BANKING WEB (BFF) APPROACH
const statusCodes = require("../utils/statusCodes");
const { logger } = require("../utils/logger");

const extractUserFromToken = (req, res, next) => {
  // Check if Okta middleware has authenticated the session
  if (req.userContext && req.userContext.userinfo) {
    const userInfo = req.userContext.userinfo;
    
    req.user = {
      userId: userInfo.sub,
      email: userInfo.email,
      name: userInfo.name || "",
      groups: userInfo.groups || [],
    };
  } else {
    req.user = null; // Treat as guest
  }
  next();
};

/**
 * STRICT AUTH: Blocks the request if no valid session cookie is found.
 * Standard for banking operations (like file uploads).
 */
const protect = (req, res, next) => {
  // req.isAuthenticated() is provided by @okta/oidc-middleware
  if (req.isAuthenticated && req.isAuthenticated()) {
    const userInfo = req.userContext.userinfo;
    
    req.user = {
      userId: userInfo.sub,
      email: userInfo.email,
      name: userInfo.name || "",
      groups: userInfo.groups || [],
    };
    return next();
  }

  // If not authenticated, return a 401
  logger.error(`Strict Auth Failed: No active banking session for ${req.originalUrl}`);
  
  const error = new Error("Unauthorized: Secure banking session required");
  error.statusCode = statusCodes.UNAUTHORIZED;
  return next(error);
};

module.exports = { 
  extractUserFromToken, 
  protect, 
  authMiddleware: protect 
};


// BOTH CODE FOR OKTA CODE SPA AND MPA
// src/middlewares/authMiddleware.js
const { spaVerifier } = require("../config/oktaConfig"); // Import the new verifier
const statusCodes = require("../utils/statusCodes"); // Assuming you have this
const { logger } = require("../utils/logger");       // Assuming you have this

// =========================================================
// A. SPA PROTECTION (Bearer Token)
// =========================================================
const protectSPA = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization || "";
    const match = authHeader.match(/Bearer (.+)/);

    if (!match) {
      return res.status(401).json({ message: "SPA Unauthorized: Bearer token required" });
    }

    const accessToken = match[1];

    // Verify the token using the new spaVerifier
    const jwt = await spaVerifier.verifyAccessToken(accessToken, 'api://default');
    
    // Attach User to Request
    req.user = {
      userId: jwt.claims.sub,
      email: jwt.claims.sub, // 'sub' is usually email/ID in Okta access tokens
      groups: jwt.claims.groups || [],
      authType: 'SPA'
    };

    return next();

  } catch (err) {
    console.error(`SPA Auth Error: ${err.message}`);
    return res.status(401).json({ message: "Invalid or Expired Token" });
  }
};

// =========================================================
// B. MPA PROTECTION (Session Cookie)
// =========================================================
const protectMPA = (req, res, next) => {
  // Check if session exists (provided by oidc middleware)
  if (req.isAuthenticated && req.isAuthenticated()) {
    
    const userInfo = req.userContext.userinfo;
    
    req.user = {
      userId: userInfo.sub,
      email: userInfo.email,
      name: userInfo.name || "",
      groups: userInfo.groups || [],
      authType: 'MPA'
    };
    
    return next();
  }

  // If not logged in:
  console.warn(`MPA Auth Failed: No session for ${req.originalUrl}`);

  // If strict API call, fail
  return res.status(401).json({ message: "Not Authenticated" });
};

module.exports = { protectSPA, protectMPA };