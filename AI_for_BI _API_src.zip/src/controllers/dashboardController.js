const { connectSnowflake } = require("../config/database");
const {
  searchInsightsByPersona,
  searchInsightById,
  updateInsightAnomalySearch,
  searchInsightDataById,
} = require("../utils/awsOpenSearch");
const { callDashboardAPI } = require("../services/agentService");
const { endpoints } = require("../config/config");
const axios = require("axios");

// ==========================================
// HELPER FUNCTIONS (SonarQube: Reduces Cognitive Complexity)
// ==========================================

/**
 * Wraps Snowflake execution in a Promise for async/await usage.
 * @param {Object} conn - Active Snowflake connection
 * @param {String} sqlText - The SQL query
 * @param {Array} binds - Array of bind parameters
 * @returns {Promise<Array>} - Query results
 */
const executeSnowflake = (conn, sqlText, binds = []) => {
  return new Promise((resolve, reject) => {
    conn.execute({
      sqlText,
      binds,
      complete: (err, stmt, rows) => {
        if (err) {
          console.error("❌ Snowflake Query Error:", err.message);
          return reject(err);
        }
        resolve(rows);
      },
    });
  });
};

/**
 * Maps Snowflake UPPERCASE column names to lowercase keys.
 * @param {Array} rows - Array of row objects from Snowflake
 * @returns {Array} - Array of objects with lowercase keys
 */
const mapToLowerCase = (rows) => {
  if (!rows || !Array.isArray(rows)) return [];
  return rows.map((row) => {
    const newRow = {};
    for (const key in row) {
      if (Object.prototype.hasOwnProperty.call(row, key)) {
        newRow[key.toLowerCase()] = row[key];
      }
    }
    return newRow;
  });
};

// ==========================================
// CONTROLLERS
// ==========================================

exports.getInsightDetails = async (req, res, next) => {
  try {
    const { personaId } = req.query;
    if (!personaId) {
      return res.status(400).json({ success: false, message: "personaId is required" });
    }

    const searchDetails = await searchInsightsByPersona(personaId);
    res.json({ success: true, data: searchDetails });
  } catch (error) {
    next(error);
  }
};

exports.homeDashboard = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { personaId, userId, clientId } = req.query;

    if (!personaId || !userId || !clientId) {
      return res.status(400).json({
        success: false,
        message: "Missing required query params (personaId, userId, clientId)",
      });
    }

    const query = `
      SELECT
        hs.VISUAL_ID, hs.VISUAL_TITLE, hs.VISUAL_SUMMARY, hs.VISUAL_TYPE,
        hs.SQL_QUERY, hs.PRIORITY, hs.PREFERENCE, hs.STATUS,
        hs.CLIENT_ID, hs.CREATED_AT, hs.UPDATED_AT
      FROM SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN hs
      JOIN SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN_PERSONA_REF hsp
        ON hs.VISUAL_ID = hsp.VISUAL_ID
      WHERE hs.STATUS = 'Y' AND hsp.PERSONA_ID = ?
      ORDER BY hs.PRIORITY ASC, hs.PREFERENCE ASC
    `;

    const rows = await executeSnowflake(conn, query, [Number(personaId)]);

    // Non-blocking Data Dictionary Trigger
    if (process.env.ENABLE_BACKGROUND_DATA_DICTIONARY === "true") {
      setImmediate(async () => {
        try {
          await axios.post(endpoints.dataDictionary, {
            user_id: Number(userId),
            persona_id: Number(personaId),
            client_id: Number(clientId),
            override_flag: false,
          });
        } catch (bgError) {
          console.warn("⚠️ Background dataDictionary failed:", bgError.message);
        }
      });
    }

    return res.json({ success: true, data: mapToLowerCase(rows) });
  } catch (error) {
    next(error);
  }
};

exports.dashboardsToPpt = async (req, res, next) => {
  try {
    const { persona_id, visual_ids_lst } = req.body;

    if (!persona_id || !visual_ids_lst?.length) {
      return res.status(400).json({ success: false, message: "persona_id and visual_ids_lst are required" });
    }

    const pythonRes = await axios.post(endpoints.dashboardsToPpt, req.body, {
      headers: { "Content-Type": "application/json" },
    });
    res.status(pythonRes.status).json(pythonRes.data);
  } catch (error) {
    next(error);
  }
};

exports.insightsToPpt = async (req, res, next) => {
  try {
    const { persona_id, insight_ids_lst } = req.body;

    if (!persona_id || !insight_ids_lst?.length) {
      return res.status(400).json({ success: false, message: "persona_id and insight_ids_lst are required" });
    }

    const pythonRes = await axios.post(endpoints.insightsToPpt, req.body, {
      headers: { "Content-Type": "application/json" },
    });
    res.status(pythonRes.status).json(pythonRes.data);
  } catch (error) {
    next(error);
  }
};

exports.homeSummary = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { personaId } = req.query;

    if (!personaId) return res.status(400).json({ success: false, message: "personaId is required" });

    const query = `
      SELECT hs.VISUAL_TITLE AS TITLE, hs.VISUAL_SUMMARY AS SUMMARY
      FROM SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN hs
      JOIN SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN_PERSONA_REF hsp ON hsp.VISUAL_ID = hs.VISUAL_ID
      WHERE hsp.PERSONA_ID = ? AND hs.STATUS = 'Y'
      ORDER BY hs.PRIORITY, hs.PREFERENCE
    `;

    const rows = await executeSnowflake(conn, query, [Number(personaId)]);

    const formattedData = {
      home_exec_summary: JSON.stringify(
        rows.map((r) => ({ title: r.TITLE, summary: r.SUMMARY }))
      ),
    };

    return res.json({ success: true, data: [formattedData] });
  } catch (error) {
    next(error);
  }
};

exports.resetVisual = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { personaId, userId } = req.query;

    if (!personaId || !userId) {
      return res.status(400).json({ success: false, message: "personaId and userId are required" });
    }

    // Reset Home Screen
    const homeQuery = `
      UPDATE SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN
      SET STATUS = 'N', UPDATED_AT = CURRENT_TIMESTAMP()
      WHERE VISUAL_ID IN (
        SELECT VISUAL_ID FROM SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN_PERSONA_REF WHERE PERSONA_ID = ?
      )
    `;

    // Reset Insights Screen
    const insightsQuery = `
      UPDATE SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN
      SET STATUS = 'N', UPDATED_AT = CURRENT_TIMESTAMP()
      WHERE INSIGHT_ID IN (
        SELECT INSIGHT_ID FROM SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN_PERSONA_REF WHERE PERSONA_ID = ?
      )
    `;

    // Execute in parallel safely
    await Promise.all([
      executeSnowflake(conn, homeQuery, [Number(personaId)]),
      executeSnowflake(conn, insightsQuery, [Number(personaId)])
    ]);

    setImmediate(async () => {
      try {
        await callDashboardAPI({ persona_id: parseInt(personaId), user_id: parseInt(userId) });
      } catch (e) {
        console.warn("Background API call failed:", e.message);
      }
    });

    res.json({ success: true, message: "Visuals and insights reset successfully" });
  } catch (error) {
    next(error);
  }
};

exports.getNextUnrefreshedInsight = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { personaId, userId } = req.query;

    if (!personaId || !userId) {
      return res.status(400).json({ success: false, message: "personaId and userId are required" });
    }

    const query = `
      SELECT i.INSIGHT_ID, i.SQL_QUERY, i.INSIGHT_ANOMALY_DATA_POINTS, i.INSIGHT_TITLE,
             i.INSIGHT_BRIEF, i.INSIGHT_SUMMARY, i.DATA_POINTS
      FROM SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN i
      JOIN SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN_PERSONA_REF r ON i.INSIGHT_ID = r.INSIGHT_ID
      WHERE r.PERSONA_ID = ? AND i.STATUS = 'N'
      ORDER BY i.INSIGHT_ID ASC LIMIT 1
    `;

    const rows = await executeSnowflake(conn, query, [Number(personaId)]);
    const data = mapToLowerCase(rows);

    res.json({ success: true, data: data[0] || {} });
  } catch (error) {
    next(error);
  }
};

exports.updateInsight = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const insightData = req.body;

    if (!insightData.insight_id) {
      return res.status(400).json({ success: false, message: "insight_id is required" });
    }

    // Prepare JSON fields safely
    const faqs = typeof insightData.insight_faqs === 'object' ? JSON.stringify(insightData.insight_faqs) : insightData.insight_faqs;
    const anomaly = typeof insightData.insight_anomaly_data_points === 'object' ? JSON.stringify(insightData.insight_anomaly_data_points) : insightData.insight_anomaly_data_points;
    const points = typeof insightData.data_points === 'object' ? JSON.stringify(insightData.data_points) : insightData.data_points;

    // Build dynamic update query to avoid overwriting fields with nulls if not provided
    // However, based on typical controller usage, specific fields are usually targeted.
    // For safety with Snowflake, we explicitly list the fields we expect to update.
    const query = `
      UPDATE SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN
      SET 
        INSIGHT_TITLE = ?,
        INSIGHT_SUMMARY = ?,
        INSIGHT_FAQS = ?,
        INSIGHT_ANOMALY_DATA_POINTS = ?,
        DATA_POINTS = ?,
        EXPLAINABILITY_SUMMARY = ?,
        CONFIDENCE_SCORE = ?,
        STATUS = 'Y',
        UPDATED_AT = CURRENT_TIMESTAMP()
      WHERE INSIGHT_ID = ?
    `;

    // Ensure we handle undefined values gracefully
    const binds = [
        insightData.insight_title || null,
        insightData.insight_summary || null,
        faqs || null,
        anomaly || null,
        points || null,
        insightData.explainability_summary || null,
        insightData.confidence_score || 0,
        insightData.insight_id
    ];

    await executeSnowflake(conn, query, binds);
    res.json({ success: true, message: "Insight updated successfully" });
  } catch (error) {
    next(error);
  }
};

exports.updateInsightAnomaly = async (req, res, next) => {
  try {
    const { data, index } = req.body;
    if (!data || !index) return res.status(400).json({ success: false, message: "data and index are required" });

    await updateInsightAnomalySearch(data, index);
    res.json({ success: true, message: "Insight anomaly updated successfully" });
  } catch (error) {
    next(error);
  }
};

exports.getNextUnrefreshedAnomaly = async (req, res, next) => {
  try {
    const { insight_id, index } = req.query;
    if (!insight_id || !index) return res.status(400).json({ success: false, message: "insight_id and index required" });

    const searchResult = await searchInsightById(insight_id, index.replace(/['"]+/g, ""));
    
    if (!searchResult || searchResult.length === 0) {
      return res.json({ success: true, data: [], message: "No anomaly data found" });
    }
    res.json({ success: true, data: searchResult });
  } catch (error) {
    const status = error.message.includes("Index name") ? 400 : 500;
    res.status(status).json({ success: false, message: error.message });
  }
};

exports.getNextUnrefreshedVisual = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { personaId } = req.body; // Logic based on original code reading from body

    if (!personaId) return res.status(400).json({ success: false, message: "personaId is required" });

    const query = `
      SELECT hs.*
      FROM SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN hs
      JOIN SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN_PERSONA_REF r ON hs.VISUAL_ID = r.VISUAL_ID
      WHERE r.PERSONA_ID = ? AND hs.STATUS = 'N'
      LIMIT 1
    `;

    const rows = await executeSnowflake(conn, query, [Number(personaId)]);
    const data = mapToLowerCase(rows);
    res.json({ success: true, data: data[0] || {} });
  } catch (error) {
    next(error);
  }
};

exports.updateVisual = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { visual_id, ...visualData } = req.body;

    if (!visual_id) return res.status(400).json({ success: false, message: "visual_id is required" });

    // Dynamic SQL Builder for Snowflake
    const fields = [];
    const binds = [];
    
    Object.keys(visualData).forEach(key => {
        // Convert camelCase to UPPER_UNDERSCORE for Snowflake column matching if necessary, 
        // assuming standard column naming conventions.
        const colName = key.replace(/([A-Z])/g, "_$1").toUpperCase();
        
        let value = visualData[key];
        if (typeof value === 'object' && value !== null) {
            value = JSON.stringify(value);
        }
        
        fields.push(`${colName} = ?`);
        binds.push(value);
    });

    fields.push("STATUS = 'Y'");
    fields.push("UPDATED_AT = CURRENT_TIMESTAMP()");
    binds.push(visual_id);

    const query = `UPDATE SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN SET ${fields.join(", ")} WHERE VISUAL_ID = ?`;

    await executeSnowflake(conn, query, binds);
    res.json({ success: true, message: "Visual updated successfully" });
  } catch (error) {
    next(error);
  }
};

exports.insightsDashboard = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { personaId } = req.query;

    if (!personaId) return res.status(400).json({ success: false, message: "personaId is required" });

    const query = `
      SELECT i.INSIGHT_ID, i.INSIGHT_TITLE, i.INSIGHT_BRIEF, i.INSIGHT_SUMMARY, 
             i.INSIGHT_FAQS, i.INSIGHT_ANOMALY_DATA_POINTS, i.DATA_POINTS, 
             i.CONFIDENCE_SCORE, i.EXPLAINABILITY_SUMMARY, i.SQL_QUERY, 
             i.INSIGHT_VISUAL_LINK, i.CREATED_AT, i.UPDATED_AT
      FROM SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN i
      JOIN SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN_PERSONA_REF r ON i.INSIGHT_ID = r.INSIGHT_ID
      WHERE r.PERSONA_ID = ? AND i.STATUS = 'Y'
      ORDER BY i.CONFIDENCE_SCORE DESC
    `;

    const rawRows = await executeSnowflake(conn, query, [Number(personaId)]);
    const insights = mapToLowerCase(rawRows);

    // Hydrate with Azure Search Data
    const insightsWithData = await Promise.all(
      insights.map(async (insightObj) => {
        try {
          const indexName = process.env.INSIGHTS_DATA_INDEX || "insight-dataframe";
          const searchData = await searchInsightDataById(insightObj.insight_id, indexName);
          
          insightObj.query_result = (searchData && searchData.length > 0) ? searchData[0].data : [];
          insightObj.query_loading = false;
        } catch (searchError) {
          console.warn(`Azure Search missing for ${insightObj.insight_id}`);
          insightObj.query_result = [];
        }
        insightObj.has_query = !!(insightObj.sql_query && insightObj.sql_query.trim().length > 0);
        return insightObj;
      })
    );

    res.json({ success: true, data: insightsWithData });
  } catch (error) {
    next(error);
  }
};

exports.executeInsightQueries = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { personaId, queries } = req.body;

    if (!personaId || !Array.isArray(queries)) {
      return res.status(400).json({ success: false, message: "personaId and queries array required" });
    }

    const results = [];
    const validQueries = queries.filter(q => q.insight_id && q.sql_query);

    // Sequential execution to manage connection load
    for (const q of validQueries) {
        let sql = q.sql_query;
        // Handle potentially JSON-wrapped SQL strings from GenAI
        if (typeof sql === "string" && sql.trim().startsWith("{")) {
            try { sql = JSON.parse(sql).sql_query || sql; } catch (e) { /* ignore */ }
        }

        const start = Date.now();
        try {
            const data = await executeSnowflake(conn, sql);
            results.push({
                insight_id: q.insight_id,
                success: true,
                data: mapToLowerCase(data),
                execution_time: Date.now() - start
            });
        } catch (err) {
            results.push({
                insight_id: q.insight_id,
                success: false,
                error: err.message,
                data: null
            });
        }
    }

    const successCount = results.filter(r => r.success).length;
    res.json({
        success: true,
        data: results,
        summary: { total: queries.length, successful: successCount, failed: results.length - successCount }
    });
  } catch (error) {
    next(error);
  }
};

exports.executeInsightQuery = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { insightId } = req.params;
    let { sql_query } = req.body;

    if (!insightId || !sql_query) return res.status(400).json({ success: false, message: "Missing params" });

    if (typeof sql_query === "string" && sql_query.trim().startsWith("{")) {
        try { sql_query = JSON.parse(sql_query).sql_query || sql_query; } catch (e) { /* ignore */ }
    }

    const start = Date.now();
    const data = await executeSnowflake(conn, sql_query);
    
    res.json({
        success: true,
        data: {
            insight_id: insightId,
            query_result: mapToLowerCase(data),
            query_execution_time: Date.now() - start,
            query_loading: false,
            query_error: null
        }
    });
  } catch (error) {
    console.error("Single Query Error:", error);
    res.status(500).json({ success: false, error: "Query execution failed", details: error.message });
  }
};

exports.getAllVisualSummaries = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { personaId } = req.query;
    
    if (!personaId) return res.status(400).json({ success: false, message: "personaId required" });

    const query = `
        SELECT p.PERSONA, hs.VISUAL_TITLE, hs.VISUAL_SUMMARY
        FROM SANDBOX_AI_BI.APP_SCHEMA.PERSONA p
        JOIN SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN_PERSONA_REF r ON p.PERSONA_ID = r.PERSONA_ID
        JOIN SANDBOX_AI_BI.APP_SCHEMA.HOME_SCREEN hs ON r.VISUAL_ID = hs.VISUAL_ID
        WHERE p.PERSONA_ID = ?
    `;

    const rows = await executeSnowflake(conn, query, [Number(personaId)]);
    
    if (rows.length === 0) return res.json({ success: false, message: "No data found" });

    res.json({
        success: true,
        data: {
            persona: rows[0].PERSONA,
            data: rows.map(r => ({ visual_title: r.VISUAL_TITLE, visual_summary: r.VISUAL_SUMMARY }))
        }
    });
  } catch (error) {
    next(error);
  }
};

exports.updateExecSummary = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { personaId, data } = req.body;

    if (!personaId || !Array.isArray(data)) return res.status(400).json({ success: false, message: "Invalid input" });

    const query = `UPDATE SANDBOX_AI_BI.APP_SCHEMA.PERSONA SET HOME_EXEC_SUMMARY = ?, UPDATED_AT = CURRENT_TIMESTAMP() WHERE PERSONA_ID = ?`;
    
    await executeSnowflake(conn, query, [JSON.stringify(data), Number(personaId)]);
    
    res.json({ success: true, message: `Successfully updated executive summary` });
  } catch (error) {
    next(error);
  }
};

exports.addKpis = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { persona_id } = req.params;
    const { KPIs } = req.body;

    if (!persona_id || !Array.isArray(KPIs)) return res.status(400).json({ success: false, message: "Invalid input" });

    // Using Promise.all for faster bulk insertion
    const insertPromises = KPIs.map(kpi => {
        const query = `
            INSERT INTO SANDBOX_AI_BI.APP_SCHEMA.KPIS 
            (KPI, DESCRIPTION, SQL_EXPRESSION, ACTION_LEVERS, PERSONA_ID, CREATED_AT)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP())
        `;
        return executeSnowflake(conn, query, [
            kpi.kpi, kpi.description, kpi.sql_expression, kpi.action_levers, persona_id
        ]);
    });

    await Promise.all(insertPromises);

    res.status(201).json({
        success: true,
        message: `Successfully added ${KPIs.length} KPI(s)`,
        data: { persona_id, kpis_added: KPIs.length }
    });
  } catch (error) {
    next(error);
  }
};

exports.getPersonaKpis = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { persona_id } = req.params;

    const query = `SELECT * FROM SANDBOX_AI_BI.APP_SCHEMA.KPIS WHERE PERSONA_ID = ? ORDER BY CREATED_AT DESC`;
    const rows = await executeSnowflake(conn, query, [persona_id]);

    res.json({
        success: true,
        data: { persona_id, kpis: mapToLowerCase(rows), total_count: rows.length }
    });
  } catch (error) {
    next(error);
  }
};

exports.insertInsightHlq = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { hlq } = req.body;

    if (!hlq) return res.status(400).json({ success: false, message: "HLQ required" });

    const query = `
        INSERT INTO SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN 
        (INSIGHT_TITLE, INSIGHT_BRIEF, INSIGHT_SUMMARY, SQL_QUERY, DATA_POINTS, STATUS, CONFIDENCE_SCORE, CREATED_AT)
        VALUES (?, ?, '', '', '', 'N', 0, CURRENT_TIMESTAMP())
    `;

    await executeSnowflake(conn, query, [hlq.substring(0, 255), hlq]);
    
    // Snowflake doesn't return Inserted ID easily in Node connector without sequence trick
    // For now, we return success.
    res.json({ success: true, data: { message: "HLQ inserted successfully" } });
  } catch (error) {
    next(error);
  }
};

exports.insertInsightPersona = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { persona_id, insight_id } = req.body;

    const checkQuery = `SELECT 1 FROM SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN_PERSONA_REF WHERE PERSONA_ID = ? AND INSIGHT_ID = ?`;
    const check = await executeSnowflake(conn, checkQuery, [persona_id, insight_id]);

    if (check.length > 0) return res.json({ success: true, message: "Association already exists" });

    const insertQuery = `INSERT INTO SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN_PERSONA_REF (PERSONA_ID, INSIGHT_ID) VALUES (?, ?)`;
    await executeSnowflake(conn, insertQuery, [persona_id, insight_id]);

    res.json({ success: true, message: "Association created" });
  } catch (error) {
    next(error);
  }
};

exports.fetchPersonaHlq = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { persona_id } = req.body;

    const query = `
        SELECT i.INSIGHT_ID, i.INSIGHT_TITLE, i.INSIGHT_BRIEF, i.STATUS, i.CREATED_AT
        FROM SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN i
        JOIN SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN_PERSONA_REF r ON i.INSIGHT_ID = r.INSIGHT_ID
        WHERE r.PERSONA_ID = ?
        ORDER BY i.CREATED_AT DESC
    `;

    const rows = await executeSnowflake(conn, query, [persona_id]);
    res.json({ success: true, data: mapToLowerCase(rows) });
  } catch (error) {
    next(error);
  }
};

exports.updateInsightStatus = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { insight_id, status } = req.body;

    const query = `UPDATE SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN SET STATUS = ?, UPDATED_AT = CURRENT_TIMESTAMP() WHERE INSIGHT_ID = ?`;
    await executeSnowflake(conn, query, [status, insight_id]);

    res.json({ success: true, message: "Insight status updated" });
  } catch (error) {
    next(error);
  }
};

exports.updateBusinessInsight = async (req, res, next) => {
  try {
    const conn = await connectSnowflake();
    const { insight_id, hlq_block, sql_query } = req.body;

    const query = `UPDATE SANDBOX_AI_BI.APP_SCHEMA.INSIGHTS_SCREEN SET INSIGHT_BRIEF = ?, SQL_QUERY = ?, UPDATED_AT = CURRENT_TIMESTAMP() WHERE INSIGHT_ID = ?`;
    await executeSnowflake(conn, query, [hlq_block, sql_query, insight_id]);

    res.json({ success: true, message: "Business insight updated" });
  } catch (error) {
    next(error);
  }
};