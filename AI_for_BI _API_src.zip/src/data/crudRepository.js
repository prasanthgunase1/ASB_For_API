const { connectSnowflake } = require("../config/database");
const { mapping } = require("../db/modelMapping");
const statusCodes = require("../utils/statusCodes");

// --- HELPER: Execute Snowflake Query Promisified ---
const execute = (sqlText, binds = []) => {
  return new Promise(async (resolve, reject) => {
    try {
      const conn = await connectSnowflake();
      conn.execute({
        sqlText,
        binds,
        complete: (err, stmt, rows) => {
          if (err) {
            console.error("❌ Repo Error:", err.message, "\nSQL:", sqlText);
            return reject(err);
          }
          resolve(rows);
        },
      });
    } catch (e) {
      reject(e);
    }
  });
};

// --- HELPER: Map Uppercase Keys to Lowercase ---
const mapKeys = (rows) => {
  if (!rows || !Array.isArray(rows)) return [];
  return rows.map((row) => {
    const newRow = {};
    for (const key in row) {
      newRow[key.toLowerCase()] = row[key];
    }
    return newRow;
  });
};

exports.findAll = async (modelName, options = {}) => {
  const tableName = mapping[modelName];
  if (!tableName) {
    const err = new Error(`Model ${modelName} not found`);
    err.statusCode = statusCodes.NOT_FOUND;
    throw err;
  }

  const { page, limit, where: whereOpts, context } = options;
  const binds = [];
  let whereClauses = [];

  // 1. Build Base Where Clauses
  if (whereOpts) {
    Object.keys(whereOpts).forEach((key) => {
      // Basic support for direct equality. 
      // Complex Op.like/Op.in would need explicit handling here.
      whereClauses.push(`${key.toUpperCase()} = ?`);
      binds.push(whereOpts[key]);
    });
  }

  // 2. Handle User Context Filtering (created_by)
  if (context?.user?.username) {
    // Assumption: All user-facing tables have CREATED_BY
    whereClauses.push("CREATED_BY = ?");
    binds.push(context.user.username);
  }

  const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(" AND ")}` : "";

  // 3. Special Handling: Conversations (Include Latest User Message)
  // Replicating Sequelize `include` logic using SQL
  if (modelName === "conversation") {
    // We use a CTE or Join to get the latest message
    // Note: Snowflake specific 'QUALIFY' makes getting latest message efficient
    const sql = `
      SELECT 
        c.*,
        m.ID as MSG_ID,
        m.MESSAGE as MSG_CONTENT,
        m.MESSAGE_TYPE as MSG_TYPE,
        m.SENDER_TYPE as MSG_SENDER,
        m.CREATED_AT as MSG_CREATED_AT
      FROM ${tableName} c
      LEFT JOIN (
          SELECT ID, CONVERSATION_ID, MESSAGE, MESSAGE_TYPE, SENDER_TYPE, CREATED_AT
          FROM ${mapping["message"]}
          WHERE SENDER_TYPE = 'user'
          QUALIFY ROW_NUMBER() OVER (PARTITION BY CONVERSATION_ID ORDER BY CREATED_AT DESC) = 1
      ) m ON c.ID = m.CONVERSATION_ID
      ${whereSql}
      ORDER BY c.UPDATED_AT DESC
      LIMIT ? OFFSET ?
    `;

    // Pagination Binds
    const offset = ((page || 1) - 1) * (limit || 10);
    const finalBinds = [...binds, limit || 10, offset];

    const rows = await execute(sql, finalBinds);
    
    // Map raw flat SQL results back to nested structure expected by frontend
    const mappedRows = mapKeys(rows).map(row => {
      const { msg_id, msg_content, msg_type, msg_sender, msg_created_at, ...conversation } = row;
      // Nest the message inside 'messages' array as Sequelize did
      if (msg_id) {
        conversation.messages = [{
          id: msg_id,
          message: msg_content,
          message_type: msg_type,
          sender_type: msg_sender,
          created_at: msg_created_at
        }];
      } else {
        conversation.messages = [];
      }
      return conversation;
    });

    return mappedRows; // Note: Service layer should handle count separately if needed
  }

  // 4. Standard findAll for other models
  const offset = ((page || 1) - 1) * (limit || 10);
  const sql = `
    SELECT * FROM ${tableName}
    ${whereSql}
    ORDER BY UPDATED_AT DESC
    LIMIT ? OFFSET ?
  `;
  
  const finalBinds = [...binds, limit || 10, offset];
  const rows = await execute(sql, finalBinds);
  return mapKeys(rows);
};

exports.findById = async (modelName, id, options = {}) => {
  const tableName = mapping[modelName];
  if (!tableName) throw { statusCode: statusCodes.NOT_FOUND, message: `Model ${modelName} not found` };

  const binds = [];
  const whereClauses = [];

  // Handle Primary Key Differences
  const pkColumn = modelName === "task" ? "TASK_ID" : "ID";
  whereClauses.push(`${pkColumn} = ?`);
  binds.push(id);

  // User Security Context
  if (options.context?.user?.username && !options.context?.systemUpdate) {
    whereClauses.push("CREATED_BY = ?");
    binds.push(options.context.user.username);
  }

  const whereSql = `WHERE ${whereClauses.join(" AND ")}`;
  const sql = `SELECT * FROM ${tableName} ${whereSql} LIMIT 1`;

  const rows = await execute(sql, binds);
  let record = mapKeys(rows)[0];

  if (!record) {
    if (options.quiet) return null;
    throw { statusCode: statusCodes.NOT_FOUND, message: "Record not found or user unauthorized" };
  }

  // 5. Special Handling: Conversation Details (Include Messages & Files)
  if (modelName === "conversation") {
    const msgTable = mapping["message"];
    const fileTable = mapping["file"];
    
    // Fetch messages
    const msgSql = `
      SELECT m.* FROM ${msgTable} m
      WHERE m.CONVERSATION_ID = ?
      ORDER BY m.CREATED_AT ASC
    `;
    const messages = await execute(msgSql, [record.id]);
    
    // Simplification: In a real app, you might fetch files via IN clause ID list
    // For now, we attach empty files array or fetch simply if needed.
    // The original Sequelize code did nested includes. 
    record.messages = mapKeys(messages).map(m => ({ ...m, files: [] }));
  }

  return record;
};

exports.create = async (modelName, data, options = {}) => {
  const tableName = mapping[modelName];
  if (!tableName) throw { statusCode: statusCodes.NOT_FOUND, message: "Model not found" };
  if (!data) throw { statusCode: statusCodes.BAD_REQUEST, message: "Invalid data" };

  // Construct INSERT
  const cols = Object.keys(data).map(k => k.toUpperCase());
  const vals = Object.values(data);
  const placeholders = vals.map(() => "?").join(", ");
  
  const sql = `
    INSERT INTO ${tableName} (${cols.join(", ")})
    VALUES (${placeholders})
  `;

  // Snowflake execute doesn't return the object.
  await execute(sql, vals);

  // Return data (plus ID if it was part of data, otherwise simplistic return)
  return data;
};

exports.update = async (modelName, id, data, options = {}) => {
  const tableName = mapping[modelName];
  if (!tableName) throw { statusCode: statusCodes.NOT_FOUND, message: "Model not found" };

  // Handle Updated By
  const updateData = { ...data };
  if (options.context?.user?.username) {
    updateData.updated_by = options.context.user.username;
    // Also update timestamp manually if DB doesn't trigger it
    updateData.updated_at = new Date(); 
  }

  const cols = [];
  const binds = [];
  
  Object.keys(updateData).forEach(key => {
    cols.push(`${key.toUpperCase()} = ?`);
    binds.push(updateData[key]);
  });

  const pkColumn = modelName === "task" ? "TASK_ID" : "ID";
  binds.push(id);

  const sql = `UPDATE ${tableName} SET ${cols.join(", ")} WHERE ${pkColumn} = ?`;

  await execute(sql, binds);

  // Fetch updated record to return
  const fetchSql = `SELECT * FROM ${tableName} WHERE ${pkColumn} = ?`;
  const rows = await execute(fetchSql, [id]);
  const updated = mapKeys(rows)[0];

  if (!updated) throw { statusCode: statusCodes.NOT_FOUND, message: "Record not found" };
  
  return updated;
};

exports.deleteRecord = async (modelName, id, options = {}) => {
  const tableName = mapping[modelName];
  if (!tableName) throw { statusCode: statusCodes.NOT_FOUND, message: "Model not found" };

  const whereClauses = ["ID = ?"];
  const binds = [id];

  if (options.context?.user?.username) {
    whereClauses.push("CREATED_BY = ?");
    binds.push(options.context.user.username);
  }

  const sql = `DELETE FROM ${tableName} WHERE ${whereClauses.join(" AND ")}`;
  
  // Note: Snowflake doesn't standardly return "rows affected" in simple `execute` result 
  // without specific driver configuration. 
  // We assume success if no error.
  await execute(sql, binds);

  return { success: true, id };
};